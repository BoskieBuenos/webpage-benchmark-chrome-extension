class Test {
    execute = () => {
        return "It works";
    }
}

export default Test;